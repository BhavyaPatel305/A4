using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoxGenerator : MonoBehaviour
{
    // Reference to the Prefab. Drag a Prefab into this field in the Inspector.
    public GameObject myPrefab;
    float pos_x_dirt = 0; // x position of dirt
    float pos_z_dirt = 0; // z position of dirt

    // Start is called before the first frame update
    void Start()
    {
        // Instantiate at position (0, 0, 0) and zero rotation.
        //Instantiate(myPrefab, new Vector3(-2.5f, 0.5f, 3f), Quaternion.identity);
        //Instantiate(myPrefab, new Vector3(3f, 0.5f, 6f), Quaternion.identity);
        //Instantiate(myPrefab, new Vector3(2f, 0.5f, -7f), Quaternion.identity);
        
    }

    // All dirt generation logic is placed here
    void generateDirt()
    {
        pos_x_dirt = Random.Range(-10f, 10f);
        pos_z_dirt = Random.Range(-10f, 10f);
        Instantiate(myPrefab, new Vector3(pos_x_dirt, 0.5f, pos_z_dirt), Quaternion.identity);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    
}
