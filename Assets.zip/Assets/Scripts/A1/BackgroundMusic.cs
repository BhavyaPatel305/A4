using UnityEngine;

public class BackgroundMusic : MonoBehaviour
{
    public AudioClip musicClip;
    private AudioSource audioSource;

    private void Start()
    {
        // Add an AudioSource component to the GameObject
        audioSource = gameObject.AddComponent<AudioSource>();

        // Set the AudioClip to be played
        audioSource.clip = musicClip;

        // Set the loop property to true
        audioSource.loop = true;

        // Play the background music
        audioSource.Play();
    }
}