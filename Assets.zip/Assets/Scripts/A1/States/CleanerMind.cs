﻿using EasyAI;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using A1.Sensors;


// AI BASED
namespace A1.States
{

    /// <summary>
    /// The global state which the cleaner is always in.
    /// </summary>
    [CreateAssetMenu(menuName = "A1/States/Cleaner Mind", fileName = "Cleaner Mind")]
    public class CleanerMind : State
    {
        
        
        public override void Execute(Agent agent)
        {
            // TODO - Assignment 1 - Complete the mind of this agent along with any sensors and actuators you need.

            // If already moving towards a tile, no need to think of anything new so simply return.
            // As mentioned in the actuator comments, you can probably see how passing transforms around will
            // become confusing in more complex agents and you can instead wrap data into of unique classes to pass.
            if (agent.HasAction<Transform>())
            {
                return;
            }

            // Sense the nearest tile.
            Floor tile = agent.Sense<NearestTileSensor, Floor>();
            if (tile == null)
            {
                return;
            }
            // Move to that nearest tile
            agent.Move(tile.transform.position);
            // Perform the cleaning action
            agent.Act(tile);
        }

        
    }
}