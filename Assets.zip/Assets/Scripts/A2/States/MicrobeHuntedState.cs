﻿using EasyAI;
using UnityEngine;
using EasyAI.Navigation;

namespace A2.States
{
    /// <summary>
    /// State for microbes that are being hunted.
    /// </summary>
    [CreateAssetMenu(menuName = "A2/States/Microbe Hunted State", fileName = "Microbe Hunted State")]
    public class MicrobeHuntedState : State
    {
        private const float GROUND_RADIUS = 10.0f;
        public override void Enter(Agent agent)
        {
            // TODO - Assignment 3 - Complete this state. Add the ability for microbes to evade hunters.
            agent.Log("I'm being hunted!");

            Execute(agent);
        }

        public override void Execute(Agent agent)
        {
            // TODO - Assignment 3 - Complete this state. Add the ability for microbes to evade hunters.
            agent.Log("I should be running away but I don't know how to yet!");
            
            Microbe mb = agent as Microbe;
            Microbe hunter = mb.Hunter;
            

            // Get the current position of the agent
            Vector3 currentPosition = agent.transform.position;

            // Check if the agent is outside the circular ground
            float distanceToCenter = Vector3.Distance(currentPosition, Vector3.zero);
            if (distanceToCenter > GROUND_RADIUS)
            {
                // Calculate the new direction for the agent to move in
                Vector3 newDirection = Vector3.Normalize(Vector3.zero - currentPosition);

                // Move the agent towards the new direction
                agent.Move(newDirection);
            }
            else
            {
                // If it is not outside circular ground than simply evade from the hunter
                agent.Move(hunter.transform, Steering.Behaviour.Evade);
            }
        }
        
        public override void Exit(Agent agent)
        {
            // TODO - Assignment 3 - Complete this state. Add the ability for microbes to evade hunters.
            agent.Log("No longer being hunted.");
            
        }
    }
}