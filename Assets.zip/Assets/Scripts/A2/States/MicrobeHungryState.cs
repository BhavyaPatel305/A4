﻿using System.Linq;
using A2.Pickups;
using A2.Sensors;
using UnityEngine;
using EasyAI;
using EasyAI.Navigation;

namespace A2.States
{
    [CreateAssetMenu(menuName = "A2/States/Microbe Hungry", fileName = "MicrobeHungry")]
    public class MicrobeHungryState : State
    {
        private MicrobeBasePickup nearestPickup;
        private bool pickupFound;
        private Microbe prey = null;
        //Microbe mb = new Microbe();

        public override void Enter(Agent agent)
        {
            Microbe mb = agent as Microbe;
            mb._targetMicrobe = null;
            
        }

        public override void Execute(Agent agent)
        {
            Microbe mb = agent as Microbe;

            // If I am hungry and right now I have no target then
            if (mb._targetMicrobe == null)
            {
                // Sense a nearest prey to eat
                NearestPreySensor preySensor = agent.GetComponent<NearestPreySensor>();
                prey = preySensor.Sense() as Microbe;
                mb.StartHunting(prey);

            }

            if (prey != null)
            {
                agent.Move(prey.transform, Steering.Behaviour.Pursue);
                
                bool succes_eating = mb.Eat();
            }
            else
            {
                // If I don't find any nearest prey to feed on then I will try to look for nearest NeverHungry Pickup

                // If no prey is found, find the nearest food pickup using the NearestPickupSensor
                NearestPickupSensor pickupSensor = agent.GetComponent<NearestPickupSensor>();
                nearestPickup = pickupSensor.Sense() as MicrobeBasePickup;
                if (nearestPickup.GetType() == typeof(NeverHungryPickup))
                {
                    // Move the microbe towards the pickup
                    agent.Move(nearestPickup.transform);
                    //Microbe mb = agent as Microbe;
                    //mb.setPickup(nearestPickup);
                }
                else
                {
                    // If I find no prey and no pickup nearby then simply roam around
                  
                    return;
                }

                    
            }

        }

        public override void Exit(Agent agent)
        {
            
        }
    }
}
