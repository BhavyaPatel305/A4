using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using EasyAI;
using System.Linq;
using System.Text;
using System.IO;
using System;



public class MicrobeTypeInField : MonoBehaviour
{
    // Static array to store the count of individual types of microbes
    // so countMicrobes[0] is for red, countMicrobes[1] orange and so on...
    public static int[] countMicrobes = Enumerable.Repeat(0, 7).ToArray();
    
    

}
