using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using A2;
using EasyAI;
using System.Linq;
using System.Text;
using System.IO;
using System;

public class MicrobeWritingToCsvFile : MonoBehaviour
{
    ArrayList data = new ArrayList(); // ArrayList to store performance values every second

    public float timer = 0f;
    public int second = 0;

    // // Used to control that value of variable no_of_tiles_cleaned is added to data array every second
    public void Update()
    {
        timer += Time.deltaTime;
        if (timer >= 1f)
        {
            timer = 0f;
            second++;
            data.Add(second + "," + MicrobeTypeInField.countMicrobes[0] + "," + MicrobeTypeInField.countMicrobes[1] + "," + MicrobeTypeInField.countMicrobes[2] + "," + MicrobeTypeInField.countMicrobes[3] + "," + MicrobeTypeInField.countMicrobes[4] + "," + MicrobeTypeInField.countMicrobes[5] + "," + MicrobeTypeInField.countMicrobes[6]);
            

        }


    }

    // This in-built function runs only when you quit the game
    // So what we want is when i quit the application, write all data to .csv file
    private void OnApplicationQuit()
    {
        WriteDataToCSV();
    }

    // Function to write data to .csv file
    public void WriteDataToCSV()
    {
        string path = Application.dataPath + "/Scripts/A2/WinningType.csv";

        string dataString = "Seconds,Red,Orange,Yellow,Green,Blue,Purple,Pink\n";
        // Build the string from the ArrayList
        for (int i = 0; i < data.Count; i++)
        {
            dataString += data[i].ToString() + "\n";
        }

        // Create the file if it doesn't exist
        if (!File.Exists(path))
        {
            File.Create(path).Close();
        }

        // Write the data to the file
        File.WriteAllText(path, dataString);
    }
}
